package com.example.expenseease;
import java.io.Serializable;

public class ExpenseModel implements Serializable {

    private String expenseId, note, category, uid;
    private long amount, time;

    public ExpenseModel(){

    }
    public ExpenseModel(String expenseId, String note, String category, String uid, long amount, long time) {
        this.expenseId = expenseId;
        this.note = note;
        this.category = category;
        this.uid = uid;
        this.amount = amount;
        this.time = time;
    }

    public String getExpenseId() {
        return expenseId;
    }

    public void setExpenseId(String expenseId) {
        this.expenseId = expenseId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
