// ReimbursementActivity.java
package com.example.expenseease;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail);

        Button backToHomeButton = findViewById(R.id.backToHomeButton);
        Button sendEmailButton = findViewById(R.id.sendEmailButton);

        backToHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MailActivity.this, HomepageActivity.class);
                startActivity(intent);
                finish(); // Optional: finish the current activity
            }
        });

        sendEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmailToAdmin();
                Toast.makeText(MailActivity.this, "Mail sent", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendEmailToAdmin() {
        String adminEmail = "khyatisanghavi999@gmail.com";
        String subject = "Reimbursement Request";
        String message = "Dear Admin,\n\nI am requesting reimbursement for my approved expenses.";

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + adminEmail));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);

        if (emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(emailIntent);
        }
    }
}
