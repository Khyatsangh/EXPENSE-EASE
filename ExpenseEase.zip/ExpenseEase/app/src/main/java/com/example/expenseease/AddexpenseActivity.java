package com.example.expenseease;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.WriteBatch;

import java.util.Calendar;
import java.util.UUID;

public class AddexpenseActivity extends AppCompatActivity {

    private EditText amountEditText, noteEditText, categoryEditText;
    private ExpenseModel expenseModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addexpense);
        amountEditText = findViewById(R.id.amount);
        noteEditText = findViewById(R.id.note);
        categoryEditText = findViewById(R.id.category);
        expenseModel = (ExpenseModel) getIntent().getSerializableExtra("model");

        if (expenseModel != null) {
            // Editing an existing expense
            amountEditText.setText(String.valueOf(expenseModel.getAmount()));
            noteEditText.setText(expenseModel.getNote());
            categoryEditText.setText(expenseModel.getCategory());
        }

        Button save = findViewById(R.id.saveButton);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (expenseModel != null) {
                    updateExpense();
                } else {
                    createExpense();
                }
            }
        });

        Button delete = findViewById(R.id.deleteButton);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteExpense();
            }
        });
    }

    private void createExpense() {
        String expenseId = UUID.randomUUID().toString();
        String amount = amountEditText.getText().toString();
        String note = noteEditText.getText().toString();
        String category = categoryEditText.getText().toString();

        if (amount.trim().length() == 0) {
            amountEditText.setError("Empty");
            return;
        }

        ExpenseModel expenseModel = new ExpenseModel(expenseId, note, category, FirebaseAuth.getInstance().getUid(), Long.parseLong(amount), Calendar.getInstance().getTimeInMillis());

        FirebaseFirestore
                .getInstance()
                .collection("expenses")
                .document(expenseId)
                .set(expenseModel);

        finish();
    }

    private void updateExpense() {
        if (expenseModel == null) {
            return;
        }

        String expenseId = expenseModel.getExpenseId();
        String amount = amountEditText.getText().toString();
        String note = noteEditText.getText().toString();
        String category = categoryEditText.getText().toString();

        if (amount.trim().length() == 0) {
            amountEditText.setError("Empty");
            return;
        }

        long amountValue = Long.parseLong(amount);

        ExpenseModel model = new ExpenseModel(
                expenseId,
                note,
                category,
                FirebaseAuth.getInstance().getUid(),
                amountValue,
                expenseModel.getTime()
            );

        FirebaseFirestore
                .getInstance()
                .collection("expenses")
                .document(expenseId)
                .set(model);
        finish();
    }


    private void deleteExpense() {
        if (expenseModel != null) {
            FirebaseFirestore
                    .getInstance()
                    .collection("expenses")
                    .document(expenseModel.getExpenseId())
                    .delete();

            finish();
        }
    }
}
