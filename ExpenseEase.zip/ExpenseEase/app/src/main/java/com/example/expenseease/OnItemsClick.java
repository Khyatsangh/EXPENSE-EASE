package com.example.expenseease;

public interface OnItemsClick {
    void onClick(ExpenseModel expenseModel);
}
