package com.example.expenseease;

import android.annotation.SuppressLint;
import android.app.assist.AssistStructure;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        TableLayout tableLayout = findViewById(R.id.tableLayout);

        // Create header row
        TableRow headerRow = new TableRow(this);
        Button backButton = findViewById(R.id.backButton);
        Button getTotalButton = findViewById(R.id.getTotalButton);
        TextView headerCategory = createTextView("Category");
        TextView headerAmount = createTextView("Amount");
        headerRow.addView(headerCategory);
        headerRow.addView(headerAmount);
        tableLayout.addView(headerRow);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ReportActivity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });

        getTotalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateTotal();
            }
        });

        // Fetch data from the database
        FirebaseFirestore.getInstance().collection("expenses")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String category = document.getString("category");
                            long amount = document.getLong("amount");

                            // Create a new row
                            TableRow row = new TableRow(ReportActivity.this);

                            // Create TextViews for category and amount
                            TextView categoryTextView = createTextView(category);
                            TextView amountTextView = createTextView(String.valueOf(amount));

                            // Add TextViews to the row
                            row.addView(categoryTextView);
                            row.addView(amountTextView);

                            // Add the row to the TableLayout
                            tableLayout.addView(row);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Handle failure, e.g., log an error
                        Log.e("ReportActivity", "Error fetching data", e);
                    }
                });
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(16, 16, 16, 16);
        return textView;
    }

    private void calculateTotal() {
        long totalAmount = 0;
        TableLayout tableLayout = findViewById(R.id.tableLayout);

        // Iterate through each TableRow in the TableLayout
        for (int i = 1; i < tableLayout.getChildCount(); i++) {
            View view = tableLayout.getChildAt(i);

            if (view instanceof TableRow) {
                TableRow row = (TableRow) view;

                // Assuming the amount is stored in the second TextView in each row
                TextView amountTextView = (TextView) row.getChildAt(1);

                // Parse the amount and add it to the total
                totalAmount += Long.parseLong(amountTextView.getText().toString());
            }
        }

        // Display the total amount as a toast message
        String totalAmountMessage = "Total Amount: " + totalAmount;
        Toast.makeText(ReportActivity.this, totalAmountMessage, Toast.LENGTH_SHORT).show();
    }

}
